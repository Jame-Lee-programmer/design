<div>

<style>

.side-by-side

{

float:left;

padding:0px 20px;

overflow:hidden;

}

  </style>

<div class="side-by-side" style="float:center;">test<?php echo $_SESSION["soutlet_name"];?></div>

<div class="side-by-side" style="float:center;"> <a href="https://www,shalimar.com"> </a> </div>

<div class="side-by-side" style="float:right;"> </div>

</div>